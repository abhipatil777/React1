// PostList.js

import React, { useEffect, useState } from 'react';
import { connect } from 'react-redux';
import { fetchPostsRequest, fetchPostsSuccess, fetchPostsFailure } from './actions';
import { fetchPosts } from './api';

const PostList = ({ posts, loading, error, fetchPosts }) => {
  const [currentPage, setCurrentPage] = useState(1);
  const [postsPerPage] = useState(10);

  useEffect(() => {
    fetchPosts(currentPage, postsPerPage);
  }, [fetchPosts, currentPage, postsPerPage]);

  const handleNextPage = () => {
    setCurrentPage((prevPage) => prevPage + 1);
  };

  const handlePrevPage = () => {
    if (currentPage > 1) {
      setCurrentPage((prevPage) => prevPage - 1);
    }
  };

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

  return (
    <div>
      {posts.map((post) => (
        <div key={post.id}>
          <h3>{post.title}</h3>
          <p>{post.body}</p>
        </div>
      ))}

      <div>
        <button onClick={handlePrevPage} disabled={currentPage === 1}>
          Previous
        </button>
        <button onClick={handleNextPage}>Next</button>
      </div>
    </div>
  );
};

const mapStateToProps = (state) => ({
  posts: state.postsReducer.posts,
  loading: state.postsReducer.loading,
  error: state.postsReducer.error,
});

const mapDispatchToProps = (dispatch) => ({
  fetchPosts: (page, limit) => {
    dispatch(fetchPostsRequest());
    fetchPosts(page, limit)
      .then((posts) => dispatch(fetchPostsSuccess(posts)))
      .catch((error) => dispatch(fetchPostsFailure(error.message)));
  },
});

export default connect(mapStateToProps, mapDispatchToProps)(PostList);
