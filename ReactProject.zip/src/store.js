// store.js

import { createStore, applyMiddleware, combineReducers } from 'redux';
import thunk from 'redux-thunk';
import postsReducer from './reducers'; // Assuming you have a 'reducers.js' file with 'postsReducer' as the reducer.

// Combine all your reducers if you have multiple.
const rootReducer = combineReducers({
  postsReducer, // Add other reducers here if needed.
});

const store = createStore(rootReducer, applyMiddleware(thunk));

export default store;