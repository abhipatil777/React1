import axios from 'axios';

export const fetchPosts = async (page, limit) => {
  try {
    const response = await axios.get(
      `https://jsonplaceholder.typicode.com/posts?_page=${page}&_limit=${limit}`
    );
    return response.data;
  } catch (error) {
    throw new Error('Failed to fetch posts.');
  }
};